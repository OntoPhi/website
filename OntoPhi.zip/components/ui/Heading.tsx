import { ReactNode } from "react";
import clsx from "clsx";

interface HeadingProps {
  children: ReactNode;
  level?: 1 | 2 | 3;
  className?: string;
}

export default function Heading({
  children,
  level = 2,
  className,
}: HeadingProps) {
  const Tag = `h${level}` as keyof JSX.IntrinsicElements;

  const styles = {
    1: "text-6xl md:text-7xl xl:text-[88px]",
    2: "text-5xl",
    3: "text-2xl",
  };

  return (
    <Tag
      className={clsx(
        styles[level],
        "font-semibold tracking-tight leading-tight",
        className
      )}
    >
      {children}
    </Tag>
  );
}
